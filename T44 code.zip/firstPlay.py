import bpy

# the directory of the file
dir = "/Users/admin/archive 2018/CAAD 2018/blender tutorial/videos/A44/"
lib01 = dir + "library01.blend"


# load the MTP code
filename = dir + "MTPcode.py"
exec(compile(open(filename).read(), filename, 'exec'))



importMeshes(lib01, ['paul'])

importMaterials(lib01, ['aubergine'])

createObject('romeo', 'paul', 'aubergine', 'Scene', (1,0,1), (0,0,0), {0})