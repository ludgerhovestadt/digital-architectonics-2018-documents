import bpy

# the directory of the file
path = "/Users/admin/archive 2018/CAAD 2018/blender tutorial/videos/A46/library02/"


def exportSelectedObjectsSeperately():
    objs = bpy.context.selected_objects
    bpy.ops.object.select_all(action='DESELECT')

    for obj in objs:
        print(obj.name)
        obj.select = True
        fPath = str((path + obj.name + '.obj'))
        bpy.ops.export_scene.obj(filepath=fPath, use_selection = True, use_materials = False, use_triangles = False, axis_forward = 'Y', axis_up = 'Z')
        obj.select = False
        

exportSelectedObjectsSeperately ()
        
    