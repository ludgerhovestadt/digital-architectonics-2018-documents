import bpy, mathutils, math
from mathutils import Matrix, Vector


# meshes

def createMesh(name, verts, edges, faces):
    msh = bpy.data.meshes.new(name)
    msh.from_pydata(verts,edges,faces)
    msh.update(calc_edges=True)


def importMeshes(library, meshNames):
    with bpy.data.libraries.load(library) as (data_from, data_to):
        data_to.meshes = meshNames


# objects

def createObject(name, mesh, material, block, loc, rot, lay):
    msh = bpy.data.meshes.get(mesh) 
    mat = bpy.data.materials.get(material)
    par = bpy.data.objects.get(block)
    obj = bpy.data.objects.new(name, msh)  
    obj.location = loc
    obj.rotation_euler = rot
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    if par: obj.parent = par
    bpy.context.scene.objects.link(obj)
    obj.layers = [i in lay for i in range(20)]
    
    
def createObjectByMatrix(name, mesh, material, block, matrix, lay):
    msh = bpy.data.meshes.get(mesh) 
    mat = bpy.data.materials.get(material)
    par = bpy.data.objects.get(block)
    obj = bpy.data.objects.new(name, msh)  
    obj.matrix_world = Matrix(matrix)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    if par: obj.parent = par
    bpy.context.scene.objects.link(obj)
    obj.layers = [i in lay for i in range(20)]   
    


# parenting    

def createBlock(par, name, loc, rot, lay):
    obj = bpy.data.objects.new(name, None)
    obj.empty_draw_size = .01
    obj.location = loc
    obj.rotation_euler = rot
    par = bpy.data.objects.get(par)
    bpy.context.scene.objects.link( obj )
    obj.layers = [i in lay for i in range(20)]
    if par: obj.parent = par


# grouping

def createGroup(name):
    bpy.ops.group.create(name=name)    
    
def addObjectToGroup(objName, grpName):
    obj = bpy.data.objects[objName]
    grp = bpy.data.groups.get(grpName)
    if grp: grp.objects.link(obj)   

def createGroupObject(name, mesh, material, block, loc, rot, lay, grpName):
    createObject(name, mesh, material, block, loc, rot, lay)
    addObjectToGroup(name, grpName)


 
def instantiateGroup(grpName, name, parName, loc, rot, lay):    
    par = bpy.data.objects.get(parName)
    grp = bpy.data.groups[grpName] 
    obj = bpy.data.objects.new(name, None)
    obj.dupli_type = 'GROUP'
    obj.dupli_group = grp
    obj.location = loc
    obj.rotation_euler = rot
    obj.empty_draw_size = .01
    if par: obj.parent = par
    bpy.context.scene.objects.link(obj)
    obj.layers = [i in lay for i in range(20)]
    
    
  
def instantiateGroupByMatrix(grpName, name, parName, matrix, lay):
    par = bpy.data.objects.get(parName)
    grp = bpy.data.groups[grpName] 
    obj = bpy.data.objects.new(name, None)
    obj.dupli_type = 'GROUP'
    obj.dupli_group = grp
    obj.matrix_world = Matrix(matrix)  
    obj.empty_draw_size = .01
    if par: obj.parent = par
    bpy.context.scene.objects.link(obj)
    obj.layers = [i in lay for i in range(20)]  
    
    
def importGroups(library, grpNames, link, lay):
    # link = False means append, link = True will link the group
    with bpy.data.libraries.load(library, link=link) as (data_from, data_to):
        data_to.groups = grpNames
        print(data_to.groups)
    for gr in data_to.groups:    
        for obj in gr.objects:
            bpy.context.scene.objects.link(obj)
            obj.layers = [i in lay for i in range(20)]
        


# the basic shaders 

def createBasicMaterial(name, color):
    mat=bpy.data.materials.get(name)
    if mat is None:mat=bpy.data.materials.new(name)

    mat.use_nodes=True
    nodes=mat.node_tree.nodes
    node=nodes.get('Diffuse BSDF')
    if node:nodes.remove(node)

    node=nodes.get('Principled BSDF')
    if node:nodes.remove(node)

    new_node=nodes.new('ShaderNodeBsdfPrincipled')
    new_node.location=(0,300)
    new_node.inputs[0].default_value=color #color
    new_node.inputs[7].default_value=0.1 #roughness
    new_node.inputs[14].default_value=1.1 #IOR
    new_node.inputs[15].default_value=0 #transmission

    output_node=nodes.get('Material Output')

    links=mat.node_tree.links
    link=links.new(new_node.outputs[0],output_node.inputs[0])
    

def importMaterials(library, matNames):
    with bpy.data.libraries.load(library) as (data_from, data_to):
        data_to.materials = matNames
    

# the basic models  
  
def cube(loc, sca, mat):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    obj=bpy.context.active_object
    obj.data.materials.append(bpy.data.materials.get(mat))
    obj.scale=sca
    
def plane(loc, sca, mat):
    bpy.ops.mesh.primitive_plane_add(location=loc)
    obj=bpy.context.active_object
    obj.data.materials.append(bpy.data.materials.get(mat))
    obj.scale=sca


# the stage   
   
def sun():
    bpy.ops.object.lamp_add(type='SUN', radius=1, location=(0, 0, 0))
    sun = bpy.data.objects['Sun']
    sun.rotation_euler = (0,math.pi/4,math.radians(240))
    sun.location += mathutils.Vector((3,0,0))
    sun.data.shadow_soft_size = 0.5
    sun.data.node_tree.nodes['Emission'].inputs['Strength'].default_value = 3
    
def camera(loc, rot, size, lens, exposure):
    bpy.ops.object.camera_add(view_align=False, location=loc, rotation=rot)
    context = bpy.context
    scene = context.scene
    currentCameraObj = bpy.data.objects['Camera']
    scene.camera = currentCameraObj    
    bpy.context.object.data.lens = lens
    bpy.context.scene.render.resolution_x = size[0]
    bpy.context.scene.render.resolution_y = size[1]
    bpy.context.scene.view_settings.exposure = exposure
    
