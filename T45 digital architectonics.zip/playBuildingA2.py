import bpy

# the directory of the file
dir = "/Users/admin/archive 2018/CAAD 2018/blender tutorial/videos/A45/"
lib01 = dir + "library01.blend"

# load the MTP code
filename = dir + "MTPcode.py"
exec(compile(open(filename).read(), filename, 'exec'))

# define the schemes for the layers
lay1 = {0}  
lay2 = {1, 3}  
lay3 = {2, 3} 

ceilling = 'ceilling_LOD2'
column = 'column_LOD2'

# the hierarchical structure of the design
createBlock('Scene','prototypes',(0,0,0),(0,0,0), lay1)
createBlock('Scene','building A',(0,0,0),(0,0,0), lay2)
createBlock('building A','floor 01',(0,0,0),(0,0,0), lay2)
createBlock('building A','floor 02',(0,0,2),(0,0,0), lay2)

# the meshes
importMeshes(lib01, [ceilling, column])

# the materials
importMaterials(lib01, ['white plaster', 'gray plaster'])

# the schemes
createGroup('module A')
createGroupObject('c01', ceilling, 'white plaster', 'prototypes', (0,0,0), (0,0,0), lay1, 'module A')
createGroupObject('c02', column, 'gray plaster', 'prototypes', (0,0,0), (0,0,0), lay1,'module A')

# the assembly of the building
instantiateGroup('module A', 'inst', 'floor 01', (0,0,0), (0,0,0), lay2)
instantiateGroup('module A', 'inst', 'floor 01', (0,3,0), (0,0,0), lay2)
instantiateGroup('module A', 'inst', 'floor 01', (3,0,0), (0,0,0), lay2)
instantiateGroup('module A', 'inst', 'floor 02', (0,0,0), (0,0,0), lay3)
