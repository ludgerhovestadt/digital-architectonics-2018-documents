import bpy
import bmesh

stage = bpy.context.scene

# Create an actor and an role
actor = bpy.data.meshes.new('paul')
role = bpy.data.objects.new('romeo', actor)

# Add the object into the scene.
stage.objects.link(role)
stage.objects.active = role
role.select = True

# change the mesh of the actor
bm = bmesh.new()
bmesh.ops.create_uvsphere(bm, u_segments=32, v_segments=16, diameter=1)
bm.to_mesh(actor)
bm.free()

# create a mask
mat=bpy.data.materials.new('aubergine')
mat.use_nodes=True
nodes=mat.node_tree.nodes
node=nodes.get('Diffuse BSDF')
if node:nodes.remove(node)

node=nodes.get('Principled BSDF')
if node:nodes.remove(node)

new_node=nodes.new('ShaderNodeBsdfPrincipled')
new_node.location=(0,300)
new_node.inputs[0].default_value=(.1,0,.8,1)#color
new_node.inputs[4].default_value=0.5 #metallic
new_node.inputs[7].default_value=0.1 #roughness
new_node.inputs[14].default_value=1.1 #IOR
new_node.inputs[15].default_value=0 #transmission

output_node=nodes.get('Material Output')

links=mat.node_tree.links
link=links.new(new_node.outputs[0],output_node.inputs[0])


# apply the mask
role.data.materials.append(mat)

# run the directive
role.location=(1,0,1)